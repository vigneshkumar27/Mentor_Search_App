import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-container',
  templateUrl: './mentor-container.component.html',
  styleUrls: ['./mentor-container.component.css']
})
export class MentorContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
